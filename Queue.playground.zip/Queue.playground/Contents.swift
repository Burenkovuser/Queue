import UIKit

struct Queue<T> {
    
    var array: [T] = []
    
    var isEmpty: Bool {
        return array.isEmpty
    }
    
    // добавляем новый элемент в очередь
    mutating func enqueue(_ element: T) {
        array.append(element)
    }
    
    // получаем первый элемент и удаляем его из очереди
    mutating func dequeue() -> T? {
        if !array.isEmpty {
            let value = array.removeFirst()
            return value
        }
        return nil
    }
    
    // получаем первый элемент очереди
    mutating func peek() -> T? {
        if !array.isEmpty {
            let value = array.first
            return value
        }
        return nil
    }
    
}

var myQueu = Queue<Int>()

myQueu.array = [1, 4, 7, 3, 89, 12]
myQueu.isEmpty
myQueu.enqueue(10)
print(myQueu)
myQueu.dequeue()
print(myQueu)
myQueu.peek()

